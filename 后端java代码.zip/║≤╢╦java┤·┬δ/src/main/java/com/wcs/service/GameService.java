package com.wcs.service;

import com.wcs.pojo.Game;
import com.wcs.pojo.Result;

public interface GameService {

    Result selectLevel(Integer chapterId, Integer levelId);


    Result userContinueStudying(String userId);

//    void insertGameUser(Integer userId, Integer chapterId, Integer levelId);
//
//    Integer passGameNumber(Integer chapterId, Integer classId);
//
//    Integer updateTime(Integer userId, Integer time);

}
