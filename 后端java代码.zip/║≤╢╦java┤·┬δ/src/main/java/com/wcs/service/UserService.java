package com.wcs.service;


import com.wcs.pojo.Class;
import com.wcs.pojo.Result;
import com.wcs.pojo.User;

import java.util.List;

/**
 * 用户--服务类-接口
 *
 *
 * 功能：1.注册
 *      2.登录
 *
 * */
public interface UserService {

    Result register(User user);

    Result login(User user);


    void quitLogin(String userId, Integer studyTime);

    Result getRemind(String userId);

    Result loginPhone(String phone);
}
