package com.wcs.service.Impl;

import com.wcs.mapper.UserMapper;
import com.wcs.pojo.Notification;
import com.wcs.pojo.Result;
import com.wcs.pojo.User;
import com.wcs.utils.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.wcs.pojo.Class;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 用户- 服务类 - 实现
 *
 *
 * 功能：1.注册
 *      2.登录
 *
 * */

@Service
public class UserServiceImp implements com.wcs.service.UserService {

    @Autowired
    UserMapper UserMapper;

    //用户注册
    @Override
    public Result register(User user) {

        //查询数据库 -> 判断用户是否已经存在
        if(UserMapper.selectUser(user.getId()) != null)
            return Result.error("用户已存在");

        if(user.getAge()<=0)
            return Result.error("年龄错误");

        if(user.getGender() != 1 && user.getGender() != 2)
            return Result.error("性别错误");

        if(user.getIdentity()!=2)
            return Result.error("用户身份错误");

        if(!user.getPhone().matches("^1[3-9]\\d{9}$"))
            return Result.error("手机号格式错误");

        if(UserMapper.selectByVxId(user.getVxId()) != null)
            return Result.error("微信号已经注册");

        //设置 创立时间
        user.setCreateTime(LocalDateTime.now());

        //插入数据
        UserMapper.register(user);

        //初始化用户关卡
        UserMapper.insertGameUserTime(user.getId(),1,0,0,0,0);

        return Result.success("注册成功");
    }

    //登录
    @Override
    public Result login(User user) {

        User u;

        //如果查找到vx ， 说明是vx登录
        if(UserMapper.selectByVxId(user.getVxId()) != null){
            u = UserMapper.selectByVxId(user.getVxId());
        }
        else if(UserMapper.login(user) != null){
            u = UserMapper.login(user);
            if(user.getVxId()!=null)
                UserMapper.updateVxId(u.getId(),user.getVxId());
        }else {
            u =null;
        }

        //登录成功，生成令牌，下发令牌
        if(u != null){
            Map<String, Object> claims = new HashMap<>();
            claims.put("id",u.getId());
            claims.put("name",u.getName());
            claims.put("vxId",u.getVxId());

            String jwt = JwtUtils.generateJwt(claims);
            return Result.success(u.getId(),jwt);
        }

        //登录失败，返回错误信息
        return Result.error("用户名或密码错误");
    }

    //教师手机号登录
    @Override
    public Result loginPhone(String phone) {
        
        User user = null;
        List<User> users = UserMapper.selectByPhone(phone);

        for (User u : users) {
            if(u.getIdentity() == 1){
                user = u;
                break;
            }
        }

        if(user == null || user.getIdentity() != 1)
            return Result.error("手机号错误");

        //登录成功，生成令牌，下发令牌
        Map<String, Object> claims = new HashMap<>();
        claims.put("id",user.getId());
        claims.put("name",user.getName());
        claims.put("vxId",user.getVxId());

        String jwt = JwtUtils.generateJwt(claims);
        // 返回用户id 和 jwt令牌
        return Result.success(user.getId(),jwt);
    }

    //查看是否有提醒
    @Override
    public Result getRemind(String userId) {
        if(UserMapper.selectUser(userId).getIdentity() != 2){
            return Result.error("不是学生");
        }
        if(UserMapper.selectRemind(userId) == 0){
            return Result.error("没有提醒");
        }
        UserMapper.seeRemind(userId);
        return Result.success(1);
    }

    //退出登录
    @Override
    public void quitLogin(String userId, Integer studyTime) {
        User user = UserMapper.selectUser(userId);
        if(user == null || user.getIdentity()!=2)
            return;
        //查询今日学习时长
        Integer timeToday = UserMapper.selectTimeToday(userId) + studyTime;
        //查询总的学习时长
        Integer timeSum = UserMapper.selectTimeSum(userId) + studyTime;
        //更新学习时长
        UserMapper.updateTime(timeToday,timeSum,userId);
    }





}
