package com.wcs.service;


import com.wcs.pojo.*;
import com.wcs.pojo.Class;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * 班级--服务类-接口
 *
 *
 * 功能：1.新建
 *
 *
 * */
public interface ClassService {

    // 查询自己所在的班级信息
    List<Class> selectClass(String id);
    //查看班级今日的平均学习时长
    List<Map<String,Integer>> selectClassAvgStudyTime(String userId);
    //查询所有班级学生学习状况
    Result selectClassAllUserStudy(String userId);
    // 查询某个班级学生的学习记录
    Result selectClassUserStudy(String userId, Integer classId);
    // 删除某条学习记录
    Result deleteUserStudy(String userId, Integer id);
    // 查询所有班级的用户个人信息
    Result selectAllClassUserDetails(String userId);
    // 查询某个班级的用户个人信息
    Result selectClassUserDetails(String userId,Integer classId);
    // 查询所有班级的用户学习信息
    Result selectAllClassUserStudyDetails(String userId);
    // 查询某个班级的用户学习信息
    Result selectClassUserStudyDetails(String userId, Integer classId);
    //创建班级
    Result createClass(Class c);
    // 批量加入班级
    Result insertClass(String teacherId, List<User> users, Integer classId);
    // 批量移除学生
    Result quitClass(String teacherId, List<String> userIds, Integer classId);
    // 删除班级
    Result deleteCLass(String userId,Integer classId);
    // 一键提醒
    Result oneClickRemind(String userId, Integer classId);
    //设置班级任务
    Result setNotification(String userId, Integer classId, LocalDate nTime, String message);

    //设置读物
    Result setReading(Reading reading);
    //查询所有读物
    Result getReading();
    //查询读物内容
    Result selectReading(String bookName);
    //删除读物
    Result deleteReading(String bookName);
}
