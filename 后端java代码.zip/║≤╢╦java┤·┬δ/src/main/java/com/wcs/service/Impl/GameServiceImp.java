package com.wcs.service.Impl;

import com.wcs.mapper.GameMapper;
import com.wcs.pojo.Game;
import com.wcs.pojo.Result;
import com.wcs.service.GameService;
import com.wcs.tcp.Client;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Slf4j
@Service
public class GameServiceImp implements GameService {

    @Autowired
    private GameMapper gameMapper;

    @Autowired
    private Client client;

    //选择章节关卡
    @Override
    public Result selectLevel(Integer chapterId, Integer levelId) {
        // 假设myGame是从数据库查询得到的Game对象
        Game game = gameMapper.selectLevel(chapterId,levelId);
        log.info("game：{}",game);
        System.out.println(Arrays.deepToString(game.getBrailleAsArray()));

        return Result.success();
    }

    //用户点击继续学习
    @Override
    public Result userContinueStudying(String userId) {

        Integer gameId = gameMapper.userContinueStudying(userId);
        System.out.println(gameId);
        Game game = gameMapper.selectLevel(gameId,1);
        System.out.println(game);
        client.sendMessage(userId+"-"+game.getChapterId()+"/"+game.getLevelId()+"/"+
                game.getChinese()+"/"+game.getBraille());

        String path =game.getChapterId().toString()+"-"+game.getLevelId().toString()+".wav";
        //发送音频
        client.sendAudio(userId,"E:\\pythonProject8\\v2h\\v2h\\level\\"+path);
        return Result.success();
    }

//    //关卡通关
//    @Override
//    public void insertGameUser(Integer userId, Integer chapterId, Integer levelId) {
//
//        //用户之前已经通关
//        if(gameMapper.selectGameUser(userId,chapterId,levelId) != 0){
//            gameMapper.updateGameUser(userId,chapterId,levelId, LocalDateTime.now());
//            return;
//        }
//
//        gameMapper.insertGameUser(userId,chapterId,levelId, LocalDateTime.now());
//    }
//
//    //查看某一章 某个班的通关人数
//    @Override
//    public Integer passGameNumber(Integer chapterId, Integer classId) {
//        return gameMapper.passGameNumber(chapterId,chapterId);
//    }
//
//    @Override
//    public Integer updateTime(Integer userId, Integer time) {
//        time = time + gameMapper.selectTodayTime(userId);
//        gameMapper.updateTodayTime(userId,time);
//        return time;
//    }

}

