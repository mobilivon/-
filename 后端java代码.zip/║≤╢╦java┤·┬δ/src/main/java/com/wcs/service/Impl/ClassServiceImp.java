package com.wcs.service.Impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.wcs.mapper.ClassMapper;
import com.wcs.mapper.UserMapper;
import com.wcs.pojo.*;
import com.wcs.pojo.Class;
import com.wcs.service.ClassService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 班级- 服务类 - 实现
 *
 *
 * 功能：1.新建班级
 *
 *
 * */
@Service
public class ClassServiceImp implements ClassService {

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private ClassMapper classMapper;


    //查询自己所在的所有班级信息
    @Override
    public List<Class> selectClass(String userId) {
        // 查询用户Id是否合法
        User user = userMapper.selectUser(userId);
        if(user == null)
            return null;

        // 如果是老师
        if(user.getIdentity() == 1)
        {
            List<Class> classes = userMapper.selectClassByTeacherId(userId);
            for (Class c:classes)
                c.setNotifications(userMapper.selectClassNotifications(c.getClassId()));
            return classes;
        }

        //如果是学生
        else if(user.getIdentity() == 2) {
            // 查询所在班级
            Class c = userMapper.selectClassByUserId(userId);
            // 查询班级的所有通知，并且按照创建时间降序排序
            List<Notification> notifications = userMapper.selectClassNotifications(c.getClassId());
            // 只保留第一个（最近的一个通知）
            List<Notification> n = new ArrayList<>();
            if(notifications!=null)
                n.add(notifications.get(0));
            c.setNotifications(n);
            List<Class> cs = new ArrayList<>();
            cs.add(c);
            return cs;
        }

        return null;
    }

    //查看班级今日的平均学习时长
    @Override
    public List<Map<String,Integer>> selectClassAvgStudyTime(String userId) {
        User user= userMapper.selectUser(userId);
        if(user == null || user.getIdentity() != 1)
            return null;

        List<Class> classes = userMapper.selectClassByTeacherId(userId);

        List<Map<String,Integer>> times = new ArrayList<>();
        for(Class c : classes)
        {
            Map<String,Integer> time = new HashMap<>();
            time.put("classId",c.getClassId());
            time.put("todayTime",c.getSTodayTime());
            time.put("sumTime",c.getSSumTime());
            times.add(time);
        }

        return times;
    }

    //查询所有班级学生学习记录
    @Override
    public Result selectClassAllUserStudy(String userId) {
        User user = userMapper.selectUser(userId);
        if(user == null || user.getIdentity()!=1)
            return null;

        List<Class> classes = userMapper.selectClassByTeacherId(userId);
        System.out.println(classes);
        List<Map<String,Integer>> gameRecord = new ArrayList<>();
        for(Class c : classes)
            gameRecord.addAll(classMapper.selectClassStudyRecord(c.getClassId()));
        return Result.success(gameRecord);
    }

    // 查询某个班级学生的学习记录
    @Override
    public Result selectClassUserStudy(String userId, Integer classId) {
        User user = userMapper.selectUser(userId);
        if(user == null || user.getIdentity()!=1)
            return null;
        Class c = classMapper.selectClass(classId);
        if(c.getTeacherId().equals(userId))
            return Result.success(classMapper.selectClassStudyRecord(classId));
        return null;
    }

    //删除某条学习记录
    @Override
    public Result deleteUserStudy(String userId, Integer id) {
        User user = userMapper.selectUser(userId);
        if(user == null || user.getIdentity()!=1)
            return null;
        String studentId = classMapper.ByRecordIdGetStudentId(id);
        if(classMapper.ifTAndSInClass(userId,studentId) >0)
        {
            classMapper.deleteUserStudyRecord(id);
            return Result.success("删除成功");
        }
        return null;
    }

    // 查询所有班级的用户个人信息
    @Override
    public Result selectAllClassUserDetails(String userId) {
        User user = userMapper.selectUser(userId);
        if(user == null || user.getIdentity()!=1)
            return null;
        List<Class> classes = userMapper.selectClassByTeacherId(userId);
        List<Map<String,String>> AllDetails = new ArrayList<>();
        for(Class c : classes)
            AllDetails.addAll(userMapper.selectClassUserDetails(c.getClassId()));

        return Result.success(AllDetails);
    }

    // 查询某个班级的用户个人信息
    @Override
    public Result selectClassUserDetails(String userId,Integer classId) {
        User user = userMapper.selectUser(userId);
        if(user == null || user.getIdentity()!=1)
            return null;
        Class c = classMapper.selectClass(classId);
        if(c.getTeacherId().equals(userId))
            return Result.success(userMapper.selectClassUserDetails(c.getClassId()));
        return null;
    }

    // 查询所有班级的用户学习信息
    @Override
    public Result selectAllClassUserStudyDetails(String userId) {
        User user = userMapper.selectUser(userId);
        if(user == null || user.getIdentity()!=1)
            return null;

        List<Class> classes = userMapper.selectClassByTeacherId(userId);
        List<Map<String,String>> AllDetails = new ArrayList<>();
        for(Class c : classes)
            AllDetails.addAll(userMapper.selectClassUserStudyDetails(c.getClassId()));

        return Result.success(AllDetails);
    }

    // 查询某个班级用户的学习信息
    @Override
    public Result selectClassUserStudyDetails(String userId, Integer classId) {
        User user = userMapper.selectUser(userId);
        if(user == null || user.getIdentity()!=1)
            return null;
        Class c = classMapper.selectClass(classId);
        if(c.getTeacherId().equals(userId))
            return Result.success(userMapper.selectClassUserStudyDetails(c.getClassId()));
        return null;
    }

    //新建班级
    @Override
    public Result createClass(Class c) {

        User user = userMapper.selectUser(c.getTeacherId());

        if(user == null ||user.getIdentity() != 1){
            return Result.error("用户权限不够");
        }else if(classMapper.selectClass(c.getClassId()) != null){
            return Result.error("班级号已存在，请更换");
        }else if(c.getClassId() == null){
            return Result.error("班级号不能为空，请更换");
        }

        c.setCreateTime(LocalDateTime.now());c.setSNumber(0);c.setSSumTime(0);c.setSTodayTime(0);
        //新建班级
        classMapper.createClass(c);

        return Result.success("成功新建班级");
    }

    // 批量向班级插入用户
    @Override
    public Result insertClass(String teacherId,List<User> users, Integer classId) {

        Class c = classMapper.selectClass(classId);

        if(c == null || !c.getTeacherId().equals(teacherId))
            return Result.error("班级号有误");

        for (User user: users) {
            User u = userMapper.selectUser(user.getId());
            if(u == null || !u.getPhone().equals(user.getPhone()) ||
                    u.getIdentity()!=2 || classMapper.selectUserClassNumber(user.getId()) >=1) {
            }
            else
                classMapper.insertUserAndClass(u.getId(), u.getName(),classId,0);
        }

        return Result.success("添加完成");
    }

    // 批量移除班级内的用户
    @Override
    public Result quitClass(String teacherId, List<String> userIds, Integer classId) {
        if(!classMapper.selectClass(classId).getTeacherId().equals(teacherId))
            return Result.error("无法操作班级");
        classMapper.quitClass(userIds,classId);
        return Result.success("批量移除成功");
    }

    //删除班级
    @Override
    public Result deleteCLass(String userId,Integer classId) {

        //查询用户是否在班级且身份是否符合
        if(userMapper.selectUser(userId).getIdentity() != 1 ||
                !classMapper.selectClass(classId).getTeacherId().equals(userId)){
            return Result.error("权限不够");
        }
        // 删除班级中所有的学生
        classMapper.deleteAllUserByClassId(classId);
        // 删除班级中的所有通知
        classMapper.deleteClassAllNotification(classId);
        //删除班级
        classMapper.deleteClass(classId);

        return Result.success("删除成功");
    }

    //一键提醒
    @Override
    public Result oneClickRemind(String userId, Integer classId) {

        //查询用户是否在班级且身份是否符合
        if(userMapper.selectUser(userId).getIdentity() != 1 ||
                !classMapper.selectClass(classId).getTeacherId().equals(userId)){
            return Result.error("权限不够");
        }
        classMapper.updateTRemain(classId);
        return Result.success();
    }

    //设置班级任务
    @Override
    public Result setNotification(String userId, Integer classId, LocalDate nTime,String message) {
        //查询用户是否在班级且身份是否符合
        if(userMapper.selectUser(userId).getIdentity() != 1 ||
                !classMapper.selectClass(classId).getTeacherId().equals(userId)){
            return Result.error("权限不够");
        }
        classMapper.updateTRemain(classId);
        classMapper.updateNotification(classId,LocalDateTime.now(),nTime,message);
        return Result.success("设置成功");
    }

    //设置读物
    @Override
    public Result setReading(Reading reading) {
        Reading read = classMapper.selectReading(reading.getBookName());
        if(read != null)
            return Result.error("读物已存在");

        reading.setTime(LocalDate.now());
        reading.setNum(0);
        classMapper.setReading(reading);
        return Result.success("添加成功");
    }

    //查询所有读物
    @Override
    public Result getReading() {
        return  Result.success(classMapper.getReading());
    }

    //查询读物内容
    @Override
    public Result selectReading(String bookName) {
        Reading read = classMapper.selectReading(bookName);
        if(read == null)
            return Result.error("查询失败");
        return Result.success(read);
    }

    @Override
    public Result deleteReading(String bookName) {
        Reading read = classMapper.selectReading(bookName);
        if(read == null)
            return Result.error("读物不存在");
        classMapper.deleteReading(bookName);
        return null;
    }


}
