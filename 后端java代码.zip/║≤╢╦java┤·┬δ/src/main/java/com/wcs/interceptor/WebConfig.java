package com.wcs.interceptor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;


/**
 * 配置拦截器
 */
@Configuration //配置类
public class WebConfig implements WebMvcConfigurer {

    @Autowired
    private LoginCheckInterceptor loginCheckInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        //拦截除了“login/register” 以外的所有网络请求
        registry.addInterceptor(loginCheckInterceptor).addPathPatterns("/**").
                excludePathPatterns("/login").excludePathPatterns("/register")
                .excludePathPatterns("/loginPhone");
    }

}
