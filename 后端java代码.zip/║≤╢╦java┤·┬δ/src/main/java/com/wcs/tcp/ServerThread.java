package com.wcs.tcp;


import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


class ServerThread extends Thread {

    private Socket socket;  //存储服务器与客户端的套接字
    private List<Map<String, Socket>> sockets; //将套接字与用户id 产生映射
    private Map<String, Socket> clientMap;


    private OutputStream outputStream;
    private InputStream inputStream;
    private byte[] buffer;

    private String saveFileName = "server_audio_file_";
    private String saveFilePath = "C:\\Users\\mobil\\Desktop"; //保存文件路径


    // 初始化线程
    public ServerThread(Socket socket, List<Map<String, Socket>> sockets) {
        this.socket = socket;
        this.sockets = sockets;
    }

    //运行线程
    @Override
    public void run() {

        try {
            //字节输入输出流
            outputStream = socket.getOutputStream();
            inputStream = socket.getInputStream();

            //读取用户id
            buffer= new byte[1024];
            int idBytesRead = inputStream.read(buffer);
            String clientId = new String(buffer, 0, idBytesRead);
            System.out.println("申请连接的客户端id:"+clientId);

            //维护List<Map>集合
            maintainListMap(clientId,socket);
            //打印List集合
            System.out.println("客户端集合："+sockets);

            //监听信息输入
            while (true) {
                synchronized (clientId){
                    //读取首行信息
                    idBytesRead = inputStream.read(buffer);
                    String message = new String(buffer, 0, idBytesRead);
                    System.out.println("接收来自 "+clientId+" 的信息："+message);

                    //对信息进行处理
                    if (message.startsWith("AUDIO:")) {
                        //接收者id
                        String receiverId = message.substring(6);
                        //保存音频 --(发送者id，接收者id)--得到音频的名字（绝对路径）
                        String fileName = saveFile(clientId,receiverId);
                        //转发音频--(发送者id,接收者id，暂时保存文件的名字)
                        forwardAudioToClient(clientId,receiverId,fileName);
                    } else {
                        //处理文本信息
                        try {
                            String[] parts = message.split("-");
                            String receiverId = parts[0];   //接收者id
                            String messageToSend = parts[1]; //待转发的文本信息
                            //转发文本信息（发送者id，接收者id，文本信息）
                            sendToClient(receiverId, clientId+"-"+messageToSend);
                        }catch (Exception e){
                            System.out.println("文本格式不规范");
                        }
                    }
                }
            }

        } catch (Exception e) {
            handleClientDisconnect(socket);
        }
    }



    //维护List<Map>集合
    private void maintainListMap(String clientId, Socket socket) {
        //构建新的Map
        clientMap = new HashMap<>();
        clientMap.put(clientId, socket);
        boolean found = false;
        //判断新的Map中的键是否已经存在， 如果存在，替换值
        for (Map<String, Socket> map : sockets) {
            if (map.containsKey(clientId)) {
                // 如果包含关键字clientId，进行替换
                map.put(clientId, socket);
                found = true;
            }
        }
        //如果不存在，将新的Map加入到List
        if(!found){
            sockets.add(clientMap);
        }
    }

    //关闭对应的socket
    private void handleClientDisconnect(Socket disconnectedSocket) {
        for (Map<String, Socket> clientMap : sockets) {
            if (clientMap.containsValue(disconnectedSocket)) {
                System.out.println(clientMap);
                sockets.remove(clientMap);
                break;
            }
        }
    }

    //保存音频（发送者id，接收者id）
    private String saveFile(String clientId,String receiverId) {
        //给文件起名字
        String fileName =saveFilePath + saveFileName + clientId + "-" + receiverId + ".mp3";
        try {
            //读取音频 并保存
            FileOutputStream fileOutputStream = new FileOutputStream(fileName,false);
            buffer = new byte[1024];
            int bytesRead;
            System.out.println("开始写入");

            while ((bytesRead = inputStream.read(buffer)) != -1) {
                // 如果缓冲区字符<=3（只剩一个END） 退出
                if(bytesRead <= 3){
                    break;
                }
                // 如果最后包含END，将END之前的字符保存 退出
                else if(new String(buffer, 0, bytesRead).endsWith("END")){
                    fileOutputStream.write(buffer, 0, bytesRead-3);
                    break;
                }
                fileOutputStream.write(buffer, 0, bytesRead);
            }

            fileOutputStream.close();
            System.out.println("写入完毕");

        }catch (Exception e){
            System.out.println("音频保存失败");
        }
        return fileName;
    }

    //转发音频，并删除存在服务器的音频(发送者id，接收者id，文件的名字)
    private void forwardAudioToClient(String clientId,String receiverId,String fileName) throws IOException {
        //查询客户端
        for (Map<String, Socket> clientMap : sockets) {
            if (clientMap.containsKey(receiverId)) {
                //获取通信通道
                Socket clientSocket = clientMap.get(receiverId);
                OutputStream outputStream = clientSocket.getOutputStream();

                //发送提示信息
                sendToClient(receiverId,"AUDIO:"+clientId);

                //发送音频文件
                FileInputStream fileInputStream = new FileInputStream(fileName);
                buffer = new byte[1024];
                int bytesRead;
                while ((bytesRead = fileInputStream.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead);
                }
                outputStream.write("END".getBytes()); //结束标志

                outputStream.flush();
                fileInputStream.close();

                //删除本地音频
                File file = new File(fileName);
                file.delete();

                System.out.println("音频转发完成");
                return;
            }
        }
    }

    //向指定客户端发送信息
    private void sendToClient(String receiverId, String message) throws IOException {
        //查询客户端
        for (Map<String, Socket> clientMap : sockets) {
            if (clientMap.containsKey(receiverId)) {
                //获取通信通道
                Socket clientSocket = clientMap.get(receiverId);

                OutputStream outputStream = clientSocket.getOutputStream();
                outputStream.write(message.getBytes(StandardCharsets.UTF_8));
                outputStream.flush();
                System.out.println(message);
                System.out.println("文本转发完成");
                return;
            }
        }
    }


}
