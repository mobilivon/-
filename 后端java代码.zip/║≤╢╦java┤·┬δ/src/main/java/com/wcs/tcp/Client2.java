package com.wcs.tcp;

import com.wcs.mapper.GameMapper;
import com.wcs.pojo.Game;
import com.wcs.service.Impl.GameServiceImp;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Client2 {

    private Socket socket;
    private OutputStream outputStream;
    private InputStream inputStream;
    private byte[] buffer = new byte[1024];


    private final String saveFilePath = "C:\\Users\\mobil\\Desktop"; //保存文件路径

    //初始化客户端
    public Client2(String clientId) {

        try {
            //创建客户端和服务器的通信通道
            socket = new Socket("localhost", 9999);

            //字节输入输出流
            outputStream = socket.getOutputStream();
            inputStream = socket.getInputStream();
            //发送id
            outputStream.write(clientId.getBytes());
            outputStream.flush();

            //开始接收信息
            startReceivingMessages();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    //开始接收信息
    private void startReceivingMessages() {
        new Thread(() -> {
            try {
                //循环接收信息
                while (true) {

                    buffer= new byte[1024];
                    int idBytesRead = inputStream.read(buffer);
                    String message = new String(buffer, 0, idBytesRead,StandardCharsets.UTF_8);
                    //如果首行信息包含AUDIO: -- 证明是音频信息
                    if (message.startsWith("AUDIO:")) {
                        //处理接收到的发送者id
                        String sendId = message.substring(6);

                        //开始接收音频并保存 -- 输入文件路径 ， 文件名字（自定义文件名）
                        saveAudioFile(saveFilePath,sendId + ".mp3");
                    }else{
                        try {
                            String[] parts = message.split("-");
                            String sendId = parts[0];   //发送者id
                            String disposeMessage = parts[1]; //待转发的文本信息
                            System.out.println("发送者："+sendId+" 有效信息:"+disposeMessage);
                        }catch (Exception e){
                            System.out.println("文本格式不规范");
                        }
                    }

                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
    }

    //发送信息（接收者id-信息）
    public void sendMessage(String message) {
        try {

            outputStream.write((message).getBytes(StandardCharsets.UTF_8));
            outputStream.flush();

            System.out.println("文本发送成功");

        } catch (IOException e) {
            e.printStackTrace();
        }

    }


    //保存音频文件
    private void saveAudioFile(String saveFilePath, String saveFileName) {
        try {
            //新建文件，新建文件的输出流
            FileOutputStream fos = new FileOutputStream(saveFilePath + saveFileName,false);
            buffer = new byte[1024];
            int bytesRead;
            //写入文件
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                // 如果缓冲区字符<=3（只剩一个END） 退出
                if(bytesRead <= 3){
                    break;
                }
                // 如果最后包含END，将END之前的字符保存 退出
                else if(new String(buffer, 0, bytesRead).endsWith("END")){
                    fos.write(buffer, 0, bytesRead-3);
                    break;
                }
                fos.write(buffer, 0, bytesRead);

            }
            fos.close();
            System.out.println("音频保存完毕");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }




    public static void main(String[] args) {

        Client2 client2 = new Client2("542213330331");
        Scanner scanner = new Scanner(System.in);
        String s;
        String[] parts = new String[2];
        while(true){

            System.out.println("请输入接收人的信息 id-message");
            s = scanner.nextLine();
            //发送信息
            client2.sendMessage(s);
        }


    }
}