package com.wcs.tcp;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Server {

    int port = 9999;

    //用户id和通信接口的映射
    private List<Map<String, Socket>> sockets = new ArrayList<>();

    //初始化服务器
    public Server() {
        try {
            ServerSocket serverSocket = new ServerSocket(port);
            System.out.println("服务器ip"+InetAddress.getLocalHost()+"\n服务器端口号"+port);

            while (true) {
                //循环监听，等待客户端创立连接
                Socket socket = serverSocket.accept();
                System.out.println("客户端连接:"+socket);
                //创立线程，交给线程类管理
                handleClient(socket);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //交给线程管理
    private void handleClient(Socket socket) {
        new ServerThread(socket, sockets).start();
    }

    //启动服务器
    public static void main(String[] args) {
        new Server();
    }
}

