package com.wcs.controller;

import com.wcs.pojo.*;
import com.wcs.pojo.Class;
import com.wcs.service.ClassService;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.annotations.Select;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

/**
 * 班级 -- 控制类
 *
 * */

@Slf4j
@RestController
public class ClassController {

    @Autowired
    private ClassService classService;

    //查询所在的所有班级 -- 教师/学生
    @GetMapping("/selectClass/{userId}")
    public Result selectClass(@PathVariable String userId){
        log.info("查询自己所在班级的信息：{}",userId);
        return Result.success(classService.selectClass(userId));
    }

    //查询班级的平均的学习时长 -- 教师
    @GetMapping("/selectClassTime/{userId}")
    public Result selectClassAvgStudyTime(@PathVariable String userId){
        log.info("查询班级平均学习时长:{}",userId);
        return Result.success(classService.selectClassAvgStudyTime(userId));
    }

    // 查询所有班级的学习记录 -- 教师
    @GetMapping("/selectAllClassUserStudy/{userId}")
    public Result selectClassAllUser(@PathVariable String userId){
        log.info("查询所有班级的学习记录,参数 {}",userId);
        return classService.selectClassAllUserStudy(userId);
    }

    // 查询某个班级的学习记录 -- 教师
    @GetMapping("/selectClassUserStudy/{userId}/{classId}")
    public Result selectClassUserStudy(@PathVariable String userId,@PathVariable Integer classId){
        log.info("查询某个班级的学习记录,参数 {},{}",userId,classId);
        return classService.selectClassUserStudy(userId,classId);
    }

    // 删除某一条学习记录 -- 教师
    @DeleteMapping("/deleteUserStudy/{userId}/{id}")
    public Result deleteUserStudy(@PathVariable String userId,@PathVariable Integer id){
        log.info("删除某一条学习记录,参数 {},{}",userId,id);
        return classService.deleteUserStudy(userId,id);
    }

    //查询所有班级的用户个人信息 -- 教师
    @GetMapping("/selectAllClassUserDetails/{userId}")
    public Result selectAllClassUserDetails(@PathVariable String userId){
        log.info("查看所有班级的用户个人信息,参数{}",userId);
        return classService.selectAllClassUserDetails(userId);
    }

    // 查询某个班级的用户个人信息 -- 教师
    @GetMapping("/selectClassUserDetails/{userId}/{classId}")
    public Result selectClassUserDetails(@PathVariable String userId,@PathVariable Integer classId){
        log.info("查看所有班级的用户个人信息,参数{}",userId);
        return classService.selectClassUserDetails(userId,classId);
    }

    //查询所有班级的用户学习信息 -- 教师
    @GetMapping("/selectAllClassUserStudyDetails/{userId}")
    public Result selectAllClassUserStudyDetails(@PathVariable String userId){
        log.info("查看所有班级的用户学习信息,参数{}",userId);
        return classService.selectAllClassUserStudyDetails(userId);
    }

    // 查询某个班级的用户学习信息 -- 教师
    @GetMapping("/selectClassUserStudyDetails/{userId}/{classId}")
    public Result selectClassUserStudyDetails(@PathVariable String userId,@PathVariable Integer classId){
        log.info("查看所有班级的用户学习信息,参数{}",userId);
        return classService.selectClassUserStudyDetails(userId,classId);
    }

    // 创建班级 -- 教师
    @PostMapping("/createClass")
    public Result createClass(@RequestBody Class c){
        log.info("新建班级:{}",c);
        return classService.createClass(c);
    }

    // 批量加入班级 -- 教师/学生
    @PostMapping ("/addClass")
    public Result insertClass(@RequestBody ClassRequest classRequest){
        log.info("教师信息:{}",classRequest.getTeacherId());
        return classService.insertClass(classRequest.getTeacherId(),classRequest.getUsers(),classRequest.getClassId());
    }

    // 批量移除学生 -- 教师
    @DeleteMapping ("/quitClass/{userId}/{userIds}/{classId}")
    public Result quitClass(@PathVariable String userId,@PathVariable List<String> userIds, @PathVariable Integer classId){
        log.info("删除用户信息:teacherId:{},userIds:{} classId:{}",userId,userIds,classId);
        return classService.quitClass(userId,userIds,classId);
    }

    //删除班级 -- 教师
    @DeleteMapping("/deleteClass/{userId}/{classId}")
    public Result deleteClass(@PathVariable String userId,@PathVariable Integer classId){
        log.info("删除班级:teacherId:{},classId:{}",userId,classId);
        return classService.deleteCLass(userId,classId);
    }

    // 教师发布一键提醒 -- 教师
    @PutMapping("/oneClickRemind")
    public Result oneClickRemind(String userId,Integer classId){
        log.info("教师向指定班级一键提醒：{},{}",userId,classId);
        return classService.oneClickRemind(userId,classId);
    }

    // 教师设置班级任务 -- 教师
    @PostMapping("/setNotification")
    public Result setNotification(String userId, Integer classId, LocalDate nTime, String notification){
        log.info("教师设置班级通知：{},{},{},{}",userId,classId,nTime,notification);
        return classService.setNotification( userId, classId,nTime,notification);
    }


    // 添加读物 -- 教师
    @PostMapping("/setReading")
    public Result setReading(@RequestBody Reading reading){
        log.info("添加读物：{}",reading);
        return classService.setReading(reading);
    }

    // 查询所有存在的读物的书名，上传者等信息(内容除外) -- 教师
    @GetMapping("/getReading")
    public Result getReading(){
        log.info("查询所有读物");
        return classService.getReading();
    }

    //查询读物 -- 教师/学生
    @GetMapping("/selectReading/{bookName}")
    public Result selectReading(@PathVariable String bookName){
        log.info("查询读物：{}",bookName);
        return classService.selectReading(bookName);
    }

    //删除读物 -- 教师
    @DeleteMapping("/deleteReading/{bookName}")
    public Result deleteReading(@PathVariable String bookName){
        log.info("删除读物:{}",bookName);
        classService.deleteReading(bookName);
        return Result.success();
    }


}
