package com.wcs.controller;

import com.wcs.pojo.Result;
import com.wcs.service.GameService;
import com.wcs.tcp.Client;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * 游戏 -- 控制类
 *
 * */

@Slf4j
@RestController
public class GameController {


    @Autowired
    private GameService gameService;

    //用户点击继续学习，接收用户id
    @GetMapping("/userContinueStudying/{userId}")
    public Result userContinueStudying(@PathVariable String userId){
        log.info("用户继续学习:{}",userId);
        return gameService.userContinueStudying(userId);
    }


    @GetMapping("/pictureChineseChange")
    public Result pictureChineseChange(String chinese,String id) throws IOException {
        log.info("图片-中文转盲文:{}",chinese);
        Client client = new Client();
        String b = getBraille(chinese);
        client.sendMessage(id + "-" +b);

        return Result.success(b);
    }





    //选择章节 关卡
    @GetMapping("/selectLevel/{userId}/{chapterId}/{levelId}")
    public Result selectLevel(@PathVariable String userId,@PathVariable Integer chapterId,@PathVariable Integer levelId){

//        //获取对应关卡的信息
//        Game game = gameService.selectLevel(chapterId,levelId);
//
//        //userId / chapterId / levelId /中文/盲文
//        Client.client.sendMessage(userId,
//                userId+"/"+game.getChapterId()+"/"+game.getLevelId()+"/"+
//                        game.getChinese()+"/"+game.getBraille());
//
//        System.out.println(userId+"/"+game.getChapterId()+"/"+game.getLevelId()+"/"+
//                game.getChinese()+"/"+game.getBraille());

        return Result.success();
    }

    public static String getBraille(String Chinese) throws IOException {
        // 设置Python解释器和脚本文件路径
        String pythonInterpreter = "C:\\Users\\mobil\\.conda\\envs\\mang\\python.exe";
        String scriptPath = "E:\\study\\pythonProject8\\main.py";
        // 创建ProcessBuilder对象并设置命令和参数
        ProcessBuilder pb = new ProcessBuilder(pythonInterpreter, scriptPath,Chinese);
        // 设置字符编码格式为UTF-8
        pb.environment().put("PYTHONIOENCODING", "UTF-8");

        // 启动进程并等待完成
        Process process = pb.start();
        try {
            process.waitFor();

            // 读取Python脚本的输出
            InputStream inputStream = process.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
            StringBuilder output = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line);
            }
            // 输出Python返回的结果
            System.out.println(output.toString());
            return output.toString();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return "";
    }

}
