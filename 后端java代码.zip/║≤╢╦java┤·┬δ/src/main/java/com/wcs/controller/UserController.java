package com.wcs.controller;

import com.wcs.pojo.Result;
import com.wcs.pojo.User;
import com.wcs.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


/**
 * 用户控制类
 *
 * */

@Slf4j
@RestController
public class UserController {

    @Autowired
    private UserService userService;

    // 用户注册
    @PostMapping("/register")
    public Result register(@RequestBody User user){
        log.info("用户注册:{}",user);
        return userService.register(user);
    }

    // 用户登录
    @PostMapping("/login")
    public Result login(@RequestBody User user){
        log.info("用户登录:{}",user);
        return userService.login(user);
    }

    // 教师手机号登录
    @PostMapping("/loginPhone")
    public Result loginPhone(String phone){
        log.info("教师手机号登录:{}",phone);
        return userService.loginPhone(phone);
    }

    //获取一键提醒
    @GetMapping("/getRemind/{userId}")
    public Result getRemind(@PathVariable String userId){
        log.info("查询自己所在班级的信息：{}",userId);
        return userService.getRemind(userId);
    }

// -------------------------------------------------

    // 用户退出登录  更新学习时长
    @PostMapping("/quitLogin")
    public Result quitLogin(String userId,Integer studyTime){
        log.info("用户退出登录:{},学习时长{}",userId,studyTime);
        userService.quitLogin(userId,studyTime);
        return Result.success();
    }





}
