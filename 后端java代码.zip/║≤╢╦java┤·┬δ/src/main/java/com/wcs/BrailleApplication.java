package com.wcs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;

/**
 * 启动类
 *  */

@ServletComponentScan //开启了对servlet组件的支持
@SpringBootApplication
public class BrailleApplication {

    public static void main(String[] args) {

        SpringApplication.run(BrailleApplication.class, args);
    }

}
