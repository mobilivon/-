package com.wcs.utils;

import com.sun.speech.freetts.Voice;
import com.sun.speech.freetts.VoiceManager;

public class TextToSpeechExample {

    public static void main(String[] args) {
        // 设置声音的名称
        System.setProperty("freetts.voices", "com.sun.speech.freetts.zh.kevin16.KevinVoiceDirectory");

        // 实例化一个VoiceManager对象
        VoiceManager voiceManager = VoiceManager.getInstance();

        // 通过VoiceManager创建一个Voice对象
        Voice voice = voiceManager.getVoice("kevin16");

        // 启动 Voice
        voice.allocate();

        // 定义要转换为语音的中文文本
        String chineseText = "学习";

        // 将中文文本转换为语音输出
        voice.speak(chineseText);

        // 关闭 Voice
        voice.deallocate();
    }



}