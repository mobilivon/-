package com.wcs.mapper;

import com.wcs.pojo.Class;
import com.wcs.pojo.Notification;
import com.wcs.pojo.User;
import org.apache.ibatis.annotations.*;
import org.springframework.beans.factory.annotation.Value;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Map;


/**
 * 用户 - 数据管理层
 * */
@Mapper
public interface UserMapper {


    // 注册- 插入用户信息
    @Insert("insert into user(id, password, name, age,gender,phone, identity, vx_id, create_time) "+
            "values (#{id}, #{password}, #{name}, #{age}, #{gender}, #{phone}, #{identity}, #{vxId},#{createTime})")
    void register(User user);

    //根据用户名 - 查询用户是否存在 -- 返回用户
    @Select("select * from user where id = #{userId} ")
    User selectUser(String userId);

    //根据用户名和密码 - 校验用户登录
    @Select("select * from user where id = #{id} and password = #{password}")
    User login(User user);

    //注册 - 初始化用户学习记录
    @Insert("insert into game_user values (#{userId},#{chapterId},#{rightNum},#{totalNum},#{gameTimeToday}, #{gameTimeSum})")
    void insertGameUserTime(String userId, Integer chapterId,Integer rightNum, Integer totalNum, Integer gameTimeToday, Integer gameTimeSum);


    /**
     * 查询学生所在班级
     * @param id
     * */
    Class selectClassByUserId(String id);


    //根据教师id 查询教师所在的班级信息（不包含通知）并返回
    @Select("select * from class where teacher_id = #{userId}")
    List<Class> selectClassByTeacherId(String userId);

    //根据班级号 查询班级的通知， 保存在list集合中 返回
    @Select("select * from class_notification where class_id = #{classId} order by c_time desc")
    List<Notification> selectClassNotifications(Integer classId);

    // 查询一个班级的用户的个人信息
    @Select("select id, user_class.class_id, user.name, age, gender, phone " +
                   "from user, class, user_class " +
                   "where  class.class_id = user_class.class_id " +
                   "and user.id = user_class.user_id and user_class.class_id = #{classId}")
    List<Map<String,String>> selectClassUserDetails(Integer classId);

    //查询一个班级的用户学习信息
    @Select("select game_user.user_id, name, class.class_id, accomplish, " +
            "chapter_id, right_num, total_num, game_time_today, game_time_sum " +
            "from game_user,class,user_class " +
            "where class.class_id = user_class.class_id " +
            "and user_class.user_id = game_user.user_id " +
            "and class.class_id = #{classId}")
    List<Map<String,String>> selectClassUserStudyDetails(Integer classId);

//    @Select("select id, user_class.class_id, user.name, game_user.chapter_id, " +
//            "age, gender, phone, right_num, total_num, game_time_today, game_time_sum " +
//            "from user, class, user_class, game_user " +
//            "where user.id = game_user.user_id and class.class_id = user_class.class_id " +
//            "and user.id = user_class.user_id and user_class.class_id = #{classId}")
//    List<Map<String,String>> selectClassUserDetails(Integer classId);




// -------------------------------



    /**
     * 更新用户
     * @param user
     */
    void update(User user);




    //查询用户今日学习时长
    @Select("select game_time_today from game_user where user_id = #{userId}")
    Integer selectTimeToday(String userId);

    //查询用户总的学习时长
    @Select("select game_time_sum from game_user where user_id = #{userId}")
    Integer selectTimeSum(String userId);

    //更新用户学习时长
    @Update("update game_user set game_time_today = #{timeToday} , game_time_sum = #{timeSum} where user_id = #{userId}")
    void updateTime(Integer timeToday, Integer timeSum,String userId);

    //查看提醒状态
    @Select("select remind from user_class where user_id = #{userId}")
    Integer selectRemind(String userId);

    //更新查询状态
    @Update("update user_class set remind = 0 where user_id = #{userId}")
    void seeRemind(String userId);

    //根据vxId查找用户
    @Select("select * from user where vx_id = #{vxId}")
    User selectByVxId(String vxId);

    //更新用户的vxId
    @Update("update user set vx_id = #{vxId} where id = #{id}")
    void updateVxId(String id, String vxId);


    @Select("select * from user where phone = #{phone}")
    List<User> selectByPhone(String phone);


}
