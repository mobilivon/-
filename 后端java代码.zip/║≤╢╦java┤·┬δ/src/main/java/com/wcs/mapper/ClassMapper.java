package com.wcs.mapper;

import com.wcs.pojo.Class;
import com.wcs.pojo.Reading;
import com.wcs.pojo.User;
import org.apache.ibatis.annotations.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * 班级 -- 数据管理层
 *
 * */

@Mapper
public interface ClassMapper {

    // 查看班级的学习记录
    @Select("select *,#{classId} AS classId from game_record where user_id in (" +
            "select user_id from user_class where class_id = #{classId})")
    List<Map<String,Integer>> selectClassStudyRecord(Integer classId);

    // 根据学习记录的id 获取对应用户id
    @Select("select user_id from game_record where id = #{id}")
    String ByRecordIdGetStudentId(Integer id);

    // 判断老师和学生是否在同一个班级
    @Select("select count(*) from class where class_id in" +
            "(select class_id from user_class where user_id = #{userId} )" +
            "and teacher_id = #{teacherId}")
    Long ifTAndSInClass(String teacherId, String userId);

    // 删除某一条学习记录
    @Delete("delete from game_record where id = #{id}")
    void deleteUserStudyRecord(Integer id);

    //查询班级
    @Select("select * from class where class_id = #{classId}")
    Class selectClass(Integer classId);

    //创建班级
    @Insert("insert into class(class_id, teacher_id, s_number,s_today_time,s_sum_time ,create_time) "+
            "values (#{classId}, #{teacherId}, #{sNumber},#{sTodayTime},#{sSumTime}, #{createTime})")
    void createClass(Class c);

    //查询用户加入班级的数量
    @Select("select count(*) from user_class where user_id = #{userId}")
    Long selectUserClassNumber(String userId);

    //将用户插入班级
    @Insert("insert into user_class(user_id, name, class_id,remind) " +
    "values (#{userId}, #{name}, #{classId},#{remind}) ")
    void insertUserAndClass(String userId, String name, Integer classId,Integer remind);

    // 批量删除指定班级的指定用户
    void quitClass(List<String> userIds, Integer classId);

    //删除一个班级内的所有人
    @Delete("delete from user_class where class_id = #{classId}")
    void deleteAllUserByClassId(Integer classId);

    // 删除班级的所有通知
    @Delete("delete from class_notification where  class_id = #{classId}")
    void deleteClassAllNotification(Integer classId);

    //删除班级
    @Delete("delete from class where class_id = #{classId}")
    void deleteClass(Integer classId);

    //老师设置一键提醒
    @Update("update user_class set remind = 1 where class_id = #{classId}")
    void updateTRemain(Integer classId);

    //设置班级任务
    @Insert("insert into class_notification(class_id, c_time, n_time, notification) " +
            "values (#{classId},#{cTime},#{nTime},#{notifacation})")
    void updateNotification(Integer classId,LocalDateTime cTime,LocalDate nTime, String notifacation);





    //设置读物
    @Insert("insert into reading(book_name, up_id, time,num,content) " +
            "values (#{bookName},#{upId},#{time},#{num},#{content})")
    void setReading(Reading reading);

    //查询所有读物
    @Select("select book_name, up_id, time, num from reading")
    List<Reading> getReading();

    // 查询读物
    @Select("select * from reading where book_name = #{bookName}")
    Reading selectReading(String bookName);

    //删除读物
    @Delete("delete from reading where book_name = #{bookName}")
    void deleteReading(String bookName);
}
