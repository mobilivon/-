package com.wcs.mapper;

import com.wcs.pojo.Game;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.time.LocalDateTime;


@Mapper
public interface GameMapper {

    //选择章节 关卡
    @Select("select * from game where chapter_id = #{chapterId} and level_id = #{levelId}")
    Game selectLevel(Integer chapterId, Integer levelId);

    //查看之前是否通关
    @Select("select count(*) from game_user where user_id=#{userId} and chapter_id=#{chapterId} and level_id = #{levelId}")
    Long selectGameUser(Integer userId, Integer chapterId, Integer levelId);

    //返回用户将要学习（章节）
    @Select("select chapter_id from game_user where user_id = #{userId}")
    Integer userContinueStudying(String userId);

    //更新用户将要学习的章节
    @Update("update game_user set chapter_id = #{content} where user_id = #{sendId}")
    void updateUserChapter(String sendId, Integer content);

    //插入学习记录
    @Insert("insert into game_record(user_id, content, study_time, right_num, total_num, pass_time) " +
            "values (#{sendId}, #{content}, #{studyTime}, #{rightNum}, #{totalNum},#{now})")
    void insertStudyRecord(String sendId, String content, Integer studyTime, String rightNum, String totalNum, LocalDateTime now);


//    //更新通关时间
//    @Update("update game_user set pass_time = #{passTime} where user_id=#{userId} and chapter_id=#{chapterId} and level_id = #{levelId}")
//    void updateGameUser(Integer userId, Integer chapterId, Integer levelId, LocalDateTime passTime);
//
//    //查看某一章 某一班的通关人数
//    @Select("select count(*) from game_user " +
//            "where chapter_id = #{chapterId} and " +
//            "user_id in (select user_id from user_class where class_id = #{classId})")
//    Integer passGameNumber(Integer chapterId, Integer classId);
//
//    @Select("select game_time_today from game_user_time where user_id = #{userId}")
//    Integer selectTodayTime(Integer userId);
//
//    @Update("update game_user_time set game_time_today = #{time} where user_id =#{userId}")
//    void updateTodayTime(Integer userId, Integer time);
}
