package com.wcs.pojo;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 结果封装类
 *
 * 将需要返回的结果 统一封装成json格式返回
 *
 * */

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Result {

    private Integer code; //状态码  1表示成功   0表示失败
    private String msg; //响应信息
    private Object data; //响应数据

    //响应成功 -- 不返回数据
    public static Result success(){
        return new Result(1,"success", null);
    }

    //响应成功 -- 返回数据
    public static Result success(Object data){
        return new Result(1,"success",data);
    }

    public static Result success(String msg,Object data){
        return new Result(1,msg,data);
    }

    //响应失败 -- 返回错误信息
    public static Result error(String msg){
        return new Result(0,msg,null);
    }

}
