package com.wcs.pojo;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 用户实体类
 *
 * */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {
    private String id; //Id
    private String password; //密码
    private String name; //姓名
    private Short age; //年龄
    private Short gender; // 性别 1-男 2-女
    private String phone; //手机号
    private Short identity; //身份 0-超级管理员 1-教师 2-学生
    private String vxId; //微信id
    private LocalDateTime createTime; //创建时间

}
