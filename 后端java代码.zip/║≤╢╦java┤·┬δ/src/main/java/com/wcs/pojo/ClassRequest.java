package com.wcs.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClassRequest {
    private String teacherId;
    private List<User> users;
    private Integer classId;
}