package com.wcs.pojo;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Game {

    private Integer chapterId; //章节id
    private Integer levelId; // 关卡id
    private String chinese; //中文
    private String braille; //盲文


    // Method to convert the braille JSON string to a 2D array
    public String[][] getBrailleAsArray() {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            return objectMapper.readValue(braille, String[][].class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            return new String[0][0]; // Return an empty array if there is an error
        }
    }


}
