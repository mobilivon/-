package com.wcs.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Reading {
    private String bookName;
    private String upId;
    private LocalDate time;
    private Integer num;
    private String content;
}
