package com.wcs.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Class {

    private Integer classId;//班级号
    private String teacherId;//老师id
    private Integer sNumber;//学生人数
    private List<Notification> notifications; // 班级通知
    private LocalDateTime createTime; //创建时间
    private Integer sTodayTime; //学生今日学习总时长
    private Integer sSumTime; //学生学习总时长
    public void setNotifications(List<Notification> notifications) {
        this.notifications = notifications;
    }
}
