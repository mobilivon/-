package com.wcs.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

// 班级通知
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Notification {
    private Integer id; //编号
    private Integer classId;//班级号
    private LocalDateTime cTime; //通知创建时间
    private LocalDate nTime; // 通知完成时间
    private String notification; // 通知内容
    private Integer number; //查看的人数
}
