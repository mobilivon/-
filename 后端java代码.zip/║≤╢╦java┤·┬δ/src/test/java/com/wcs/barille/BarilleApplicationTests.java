package com.wcs.barille;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;

@SpringBootTest
class BarilleApplicationTests {



    @Test
    public void getBrailleAsArray() throws IOException {
        // 设置Python解释器和脚本文件路径
        String pythonInterpreter = "C:\\Users\\mobil\\.conda\\envs\\mang\\python.exe";
        String scriptPath = "E:\\study\\pythonProject8\\add.py";

        // 创建ProcessBuilder对象并设置命令和参数
        ProcessBuilder pb = new ProcessBuilder(pythonInterpreter, scriptPath,"[['1345', '24'], ['125', '235'], ['156', '0'], ['1245', '15']]" );

        // 设置字符编码格式为UTF-8
        pb.environment().put("PYTHONIOENCODING", "UTF-8");
        System.out.println("chengxuqidong");
        // 启动进程并等待完成
        Process process = pb.start();
        try {
            process.waitFor();

            // 读取Python脚本的输出
            InputStream inputStream = process.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
            StringBuilder output = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line);
            }

            String str = output.toString();
            System.out.println(str);
            String[] array = str.substring(1, str.length() - 1).split(", ");


            // 创建一个 StringBuilder 对象来拼接数组元素
            StringBuilder result= new StringBuilder();
            for (String element : array) {
                element = element.substring(1, element.length() - 1);
                result.append(element);
            }
            System.out.println(result);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


    }


    @Test
    public void getBraille() throws IOException {
        // 设置Python解释器和脚本文件路径
        String pythonInterpreter = "C:\\Users\\mobil\\.conda\\envs\\mang\\python.exe";
        String scriptPath = "E:\\study\\pythonProject8\\main.py";
        // 创建ProcessBuilder对象并设置命令和参数
        ProcessBuilder pb = new ProcessBuilder(pythonInterpreter, scriptPath,"你好世界");
        // 设置字符编码格式为UTF-8
        pb.environment().put("PYTHONIOENCODING", "UTF-8");

        // 启动进程并等待完成
        Process process = pb.start();
        try {
            process.waitFor();

            // 读取Python脚本的输出
            InputStream inputStream = process.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
            StringBuilder output = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line);
            }
            // 输出Python返回的结果
            System.out.println(output.toString());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }



    }


    @Test
    public void getV() throws IOException {
        // 设置Python解释器和脚本文件路径
        String pythonInterpreter = "python";
        String scriptPath = "E:\\pythonProject8\\v2h\\v2h\\main.py";
        String text= "这是最终测试";
        String userId = "54221";
        String c = "4";
        String l = "3";
        // 创建ProcessBuilder对象并设置命令和参数
        ProcessBuilder pb = new ProcessBuilder(pythonInterpreter, scriptPath, text,userId);

        // 设置字符编码格式为UTF-8
        pb.environment().put("PYTHONIOENCODING", "UTF-8");

        // 启动进程并等待完成
        Process process = pb.start();
        try {
            process.waitFor();

            // 读取Python脚本的输出
            InputStream inputStream = process.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
            StringBuilder output = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line);
            }

            // 将拼接后的字符串输出
            System.out.println(output.toString());


        } catch (InterruptedException e) {
            e.printStackTrace();
        }


    }


}
