#include "stm32f10x.h"                  // Device header

int main{
	while(1){
		
	}
}
