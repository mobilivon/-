#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
//#include "HC-05.h"
#include "74HC595.h"
#include "a4988.h"
#include "Timer.h"
#include "Serial.h"

uint8_t RxData;

int main(void)
{
	OLED_Init();
//	HC_05_Init();
	HC595_Init();
	A4988_Init();
	Timer_Init();
	Serial_Init();
	
//	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
//	
//	GPIO_InitTypeDef GPIO_InitStructure;
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
//	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_0;
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
//ȫ���ȳ�ʼ��
	Send_Data(0x00, 0x00, 1);
	Send_Data(0x00, 0x00, 2);
	Send_Data(0x00, 0x00, 3);
	Send_Data(0x00, 0x00, 4);
//	reverse();
//Clear_all();
	
	TIM_Cmd(TIM2,ENABLE);
	OLED_ShowString(1,1,"Len:");
	

	while(1){
		
		if(Serial_GetRxFlag() == 1)
		{
			OLED_ShowString(1,1,"Len:");
			OLED_ShowHexNum(1,5,Serial_RxLen, 2);
			OLED_ShowHexNum(2,1,Serial_RxPacket[0], 2);
			OLED_ShowHexNum(3,1,Serial_RxPacket[3], 2);
			write();
		}
		

//		Clear_all();
		
//		OLED_ShowHexNum(2,1,a,2);
//			for(int i = 0;i<100;i++)
//		{
//			Set_Compare3(i);
//			Delay_ms(10);
//		}
//		for(int i = 100;i>0;i--                                                                                                                                                             )
//		{
//			Set_Compare3(i);
//			Delay_ms(10);
//		}
//		if(Serial_GetRxFlag() == 1){
//			RxData = Serial_GetRxData();
//			Serial_SendByte(RxData);
//			OLED_ShowHexNum(1,1,RxData,2);	
//		}
//		for(uint16_t i = 0; i < 800; i++)
//		{
//			GPIO_ResetBits(GPIOB, GPIO_Pin_0);
//			Delay_ms(1);
//			GPIO_SetBits(GPIOB, GPIO_Pin_0);
//			Delay_ms(1);
//		}
	}
}


//int main(void)
//{
//	OLED_Init();
////	HC_05_Init();
//	HC595_Init();
//	A4988_Init();
//	Timer_Init();
//	Serial_Init();


//	while(1){
//		if(
//	}
//}

