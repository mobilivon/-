#include "stm32f10x.h"                  // Device header
#include "74HC595.h"
#include "OLED.h"
#include "delay.h"
#include "Serial.h"

uint8_t C595_Data[8];

void HC595_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	//DAT
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP ;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_2 | GPIO_Pin_4 | GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	//CLK
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_3 | GPIO_Pin_5 | GPIO_Pin_7;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	//SCK
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_ResetBits(GPIOA,GPIO_Pin_0 | GPIO_Pin_2 | GPIO_Pin_4 | GPIO_Pin_6 
					| GPIO_Pin_1 | GPIO_Pin_3 | GPIO_Pin_5 | GPIO_Pin_7 | GPIO_Pin_8);
					
	for(int i = 0;i < 8;i++)
	{
		C595_Data[i] = 0x00;
		Serial_RxPacket[i] = 0x00;
	}
}

void Send_Byte_1(uint8_t Data1, uint8_t Data2)
{
	uint16_t temp = ((Data2 << 8) | Data1);
//	OLED_ShowHexNum(1,1,temp,4);
	CLK_1_H;
	for(uint8_t i = 0; i < 16; i++)
	{
		
		if((temp & 0x8000) == 0x8000)
		{
			Data_1_H;
//			OLED_ShowNum(i+1,1,1,2);
		}
		else
		{
			Data_1_L;
		}
		temp <<= 1;
		CLK_1_L;
		Delay_us(20);
		CLK_1_H;
	}
}

void Send_Byte_2(uint8_t Data1, uint8_t Data2)
{
	uint16_t temp = (Data2 << 8) | Data1;
	
	CLK_2_H;
	for(uint8_t i = 0; i < 16; i++)
	{
		
		if((temp & 0x8000) == 0x8000)
		{
			Data_2_H;
//			OLED_ShowNum(i+1,1,1,2);
		}
		else
		{
			Data_2_L;
		}
		temp <<= 1;
		CLK_2_L;
		Delay_us(20);
		CLK_2_H;
	}

}

void Send_Byte_3(uint8_t Data1, uint8_t Data2)
{
	uint16_t temp = (Data2 << 8) | Data1;
	
	CLK_3_H;
	for(uint8_t i = 0; i < 16; i++)
	{
		
		if((temp & 0x8000) == 0x8000)
		{
			Data_3_H;
//			OLED_ShowNum(i+1,1,1,2);
		}
		else
		{
			Data_3_L;
		}
		temp <<= 1;
		CLK_3_L;
		Delay_us(20);
		CLK_3_H;
	}
}

void Send_Byte_4(uint8_t Data1, uint8_t Data2)
{
	uint16_t temp = (Data2 << 8) | Data1;
	
	CLK_4_H;
	for(uint8_t i = 0; i < 16; i++)
	{
		
		if((temp & 0x8000) == 0x8000)
		{
			Data_4_H;
//			OLED_ShowNum(i+1,1,1,2);
		}
		else
		{
			Data_4_L;
		}
		temp <<= 1;
		CLK_4_L;
		Delay_us(20);
		CLK_4_H;
	}
}

void Send_Data(uint8_t Data1, uint8_t Data2, uint8_t num)
{
	switch(num){
		case 1:	
			OLED_ShowHexNum(4,1,C595_Data[0], 2);
			SCK_L;
			Send_Byte_1(~Data1, ~Data2);
			SCK_H;
			break;
		case 2:
			SCK_L;
			Send_Byte_2(~Data1, ~Data2);
			SCK_H;
			break;
		case 3:
			SCK_L;
			Send_Byte_3(~Data1, ~Data2);
			SCK_H;
			break;
		case 4:
			SCK_L;
			Send_Byte_4(~Data1, ~Data2);
			SCK_H;
			break;
	}
}


