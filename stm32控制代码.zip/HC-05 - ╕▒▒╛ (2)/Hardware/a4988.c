#include "stm32f10x.h"                  // Device header
#include "74HC595.h"
#include "Serial.h"
#include "Timer.h"
#include "a4988.h"

//��Ӧ��key0��key1
void A4988_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);
//	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
//	GPIO_InitTypeDef GPIO_InitStructure;
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
//	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//	GPIO_Init(GPIOB, &GPIO_InitStructure);
//	
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
//	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
//	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	TIM_InternalClockConfig(TIM3);
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseStructure.TIM_Period = 200-1;
	TIM_TimeBaseStructure.TIM_Prescaler = 720-1;
	TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
	
	TIM_OCInitTypeDef TIM_OCInitStruct;
	TIM_OCStructInit(&TIM_OCInitStruct);
	TIM_OCInitStruct.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStruct.TIM_OCPolarity = TIM_OCPolarity_High;
	TIM_OCInitStruct.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStruct.TIM_Pulse = 100;
	TIM_OC3Init(TIM3, &TIM_OCInitStruct);
	
	TIM_Cmd(TIM3,ENABLE);
}

void Set_Compare3(uint8_t Num)
{
	TIM_SetCompare3(TIM3, Num); 
}

void forward(void)
{
	GPIO_SetBits(GPIOB, GPIO_Pin_1);
}

void reverse(void)
{
	GPIO_ResetBits(GPIOB, GPIO_Pin_1);
}

void TIM2_Cmd(void)
{
	TIM_Cmd(TIM2,ENABLE);
	Tim2_Flag = 0;
}

void write(void)
{
	Clear_all();
	while(!Tim2_Flag);
	forward();
	for(int i = 0; i < Serial_RxLen/2 + 1; i++)
	{
		C595_Data[i * 2] = Serial_RxPacket[i * 2];
		C595_Data[i * 2 + 1] = Serial_RxPacket[i * 2 + 1];
		Send_Data(Serial_RxPacket[i * 2], Serial_RxPacket[i * 2 + 1], i + 1);
	}
	TIM2_Cmd();
	while(!Tim2_Flag);
	reverse();
}


//void write(void)
//{
//	reverse();
//	Send_Data(data1, data2, 1);
//	TIM2_Cmd();
//	data1 = ~data1;
//	data2 = ~data2;
//	while(!Tim2_Flag);
//	forward();
//	Send_Data(data1, data2, 1);
//	TIM2_Cmd();
//}


void Clear_all(void)
{
	while(!Tim2_Flag);
	reverse();
	for(uint8_t i = 0; i < 4; i++)
	{
		Send_Data(C595_Data[i * 2], C595_Data[i * 2 + 1], i + 1);
		C595_Data[i * 2] = C595_Data[i * 2 + 1] = 0x00;
	}
	TIM2_Cmd();
}

//void Clear_all(void)
//{
//	while(!Tim2_Flag);
//	reverse();
//	Send_Data(0x00, 0xFF, 1);
//	TIM2_Cmd();
//}

void stop(void)
{
	for(uint8_t i = 0; i < 4; i++)
		{
			Send_Data(0x00, 0x00, i+1);
		}
}

