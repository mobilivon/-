#include "stm32f10x.h"                  // Device header
#include "Timer.h"
#include "Delay.h"
#include "Timer.h"
uint8_t a = 0;
uint8_t Tim2_Flag = 1;

void Timer_Init(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
	
	TIM_InternalClockConfig(TIM2);
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseStructure.TIM_Period = 10000-1;
	TIM_TimeBaseStructure.TIM_Prescaler = 7200-1;
	TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
	
	TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE);
	
	TIM_ClearFlag(TIM2,TIM_IT_Update);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	NVIC_InitTypeDef NVIC_InitStruct;
	NVIC_InitStruct.NVIC_IRQChannel = TIM2_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStruct);
	
	TIM_Cmd(TIM2,DISABLE);
}	

//void TIM2_IRQHandler(void){
//	if(TIM_GetITStatus(TIM2,TIM_IT_Update)== SET){
////		TIM_Cmd(TIM2,DISABLE);
//		Delay_ms(100);
//		if(a == 0)
//		{
//			a = 1;
//			forward();
//		}else if(a == 1)
//		{
//			a = 0;
//			reverse();
//		}
////		a++;
//		TIM_ClearITPendingBit(TIM2,TIM_IT_Update);
//	}
//}

void TIM2_IRQHandler(void){
	if(TIM_GetITStatus(TIM2,TIM_IT_Update)== SET){
		TIM_Cmd(TIM2,DISABLE);
		stop();
		Tim2_Flag = 1;
		TIM_ClearITPendingBit(TIM2,TIM_IT_Update);
	}
}


