#ifndef __A4988_H
#define __A4988_H


void A4988_Init(void);
void Set_Compare3(uint8_t Num);
void forward(void);
void reverse(void);
void write(void);
void Clear_all(void);
void stop(void);


#endif

