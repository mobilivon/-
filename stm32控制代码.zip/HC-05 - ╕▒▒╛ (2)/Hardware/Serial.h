#ifndef __SERIAL_H
#define __SERIAL_H

extern uint8_t Serial_RxPacket[8];
extern uint8_t Serial_RxFlag;
extern uint8_t Serial_RxLen;

void Serial_Init(void);
uint8_t Serial_GetRxFlag(void);

#endif
