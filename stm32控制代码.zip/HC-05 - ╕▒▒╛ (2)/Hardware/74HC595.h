#ifndef __74HC595_H
#define __74HC595_H

#define SCK_H	GPIOA->BSRR = GPIO_Pin_8
#define SCK_L  	GPIOA->BRR  = GPIO_Pin_8

#define Data_1_H	GPIOA->BSRR = GPIO_Pin_0
#define Data_1_L	GPIOA->BRR  = GPIO_Pin_0
#define CLK_1_H 	GPIOA->BSRR = GPIO_Pin_1
#define CLK_1_L 	GPIOA->BRR  = GPIO_Pin_1

#define Data_2_H	GPIOA->BSRR = GPIO_Pin_2
#define Data_2_L	GPIOA->BRR  = GPIO_Pin_2
#define CLK_2_H 	GPIOA->BSRR = GPIO_Pin_3
#define CLK_2_L 	GPIOA->BRR  = GPIO_Pin_3

#define Data_3_H	GPIOA->BSRR = GPIO_Pin_4
#define Data_3_L	GPIOA->BRR  = GPIO_Pin_4
#define CLK_3_H 	GPIOA->BSRR = GPIO_Pin_5
#define CLK_3_L 	GPIOA->BRR  = GPIO_Pin_5

#define Data_4_H	GPIOA->BSRR = GPIO_Pin_6
#define Data_4_L	GPIOA->BRR  = GPIO_Pin_6
#define CLK_4_H 	GPIOA->BSRR = GPIO_Pin_7
#define CLK_4_L 	GPIOA->BRR  = GPIO_Pin_7

extern uint8_t C595_Data[8];

void HC595_Init(void);
void Send_Data(uint8_t Data1, uint8_t Data2, uint8_t num);

#endif


